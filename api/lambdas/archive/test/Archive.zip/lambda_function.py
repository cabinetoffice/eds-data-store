import psycopg2  # pip install psycopg2-binary -t .
from psycopg2.extras import RealDictCursor
import json


def db_conn():
    db = {
        'host': 'equality-data-store-instance-1.ciyx9q7bb8hh.eu-west-2.rds.amazonaws.com',
        'username': 'postgres',
        'password': 't1N5BKna2WhoQC58Eai5OYlOlJtqZ-it',
        'database': 'eds',
    }

    return psycopg2.connect(
        host = db['host'],
        user = db['username'],
        password = db['password'],
        database = db['database']
    )

def lambda_handler(event, context):
    conn = db_conn()
    cursor = conn.cursor(cursor_factory=RealDictCursor)
    cursor.execute('SELECT * FROM "Datasource"')
    results = cursor.fetchall()
    #print(json.dumps(results))

    return {
        'statusCode': 200,
        'body': json.dumps(results)
    }

#lambda_handler(None, None)
